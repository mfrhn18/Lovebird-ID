<?php $__env->startSection('content'); ?>
<main role="main">
  <section class="content-header">
    <h1>
      Finance
      <small>Information</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active"><a href="#"><i class="fa fa-dollar"></i> Finance</a></li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="box">
          <div class="box-header">
            <div class="pull-left">
              <hi class="box-title">
                Jurnal Keuangan
              </h1>
            </div>
            <div class="pull-right">
              <?php echo $__env->make('addjournal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>

        <div class="box">
          <div class="box-body">
            <div class="row">
              <?php $__currentLoopData = $data['data']['user']['journal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo e($journal['timeStamp']); ?></h3>
                    </div>
                    <a href="<?php echo e(route('journaldetails.show', $journal['id'])); ?>" class="small-box-footer">Details <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/finance.blade.php ENDPATH**/ ?>