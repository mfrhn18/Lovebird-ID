<?php $__env->startSection('content'); ?>
<main role="main">
    <section class="content-header">
        <h1>
            BirdFarm
            <small>Management</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="birdfarm"><i class="glyphicon glyphicon-info-sign"></i> BirdFarm</a></li>
            <li class="active"><a href="#"> Register Induk</a></li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="box">
                    <div class="box-body">
                        <form method="POST" action="<?php echo e(route('reginduk.store')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="noParent">No. Induk</label>
                                <input name="noParent" type="text" class="form-control" id="noParent" placeholder="No. Induk">
                            </div>
                            <div class="form-group">
                                <label for="male">List Burung Jantan</label>
                                <select name="male" id="male" class="form-control">
                                
                                    <?php $__currentLoopData = $data['data']['user']['birdOwned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $male): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option selected value="<?php echo e($male['id']); ?>"><?php echo e($male['ring']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="female">List Burung Betina</label>
                                <select name="female" id="female" class="form-control">
                                    <?php $__currentLoopData = $data['data']['user']['birdOwned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $female): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option selected value="<?php echo e($female['id']); ?>"><?php echo e($female['ring']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Register</button>
                        </form>           
                    </div> 
                </div>
            <div class="col-md-3"></div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/reginduk.blade.php ENDPATH**/ ?>