<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2019 <a href="#">Lovebird ID</a>.</strong> All rights
    reserved.
</footer><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/layouts/footer.blade.php ENDPATH**/ ?>