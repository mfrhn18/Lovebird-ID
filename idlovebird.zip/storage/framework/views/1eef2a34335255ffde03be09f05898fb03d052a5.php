<!-- Button -->
<div class="button">
    <button type="button" class="btn btn-block btn-sm bg-orange" data-toggle="modal" data-target="#birdDetails">
        Details
    </button>
</div>

<!-- Modal -->
<div class="modal fade" id="birdDetails">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Bird Details</h4>
            </div>

            <div class="modal-body">
                <div id="gallery" class="row">
                    <div class="col-xs-12">
                        <!-- Gallery -->
                        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner" role="listbox">
                                <div class="item active">
                                    <img src="https://cdn10.bigcommerce.com/s-nadnq/product_images/uploaded_images/31.jpg" alt="First Slide">
                                </div>
                                <div class="item">
                                    <img src="https://awsimages.detik.net.id/community/media/visual/2018/05/07/c5df5cf2-9799-4913-afdc-1fee86ce297e_169.jpeg?w=780&q=90" alt="...">
                                </div>
                            </div>

                            <!-- Controls -->
                            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>

                <div id="info" class="row">
                    <div class="col-xs-12">
                        
                            <!-- Information -->
                            <h3>Lovebird A</h3>
                            <hr>
                            <table class="mt-3 pt-3 mb-1 pb-1" id="userdetails">
                                <tbody>
                                <tr>
                                    <td>Nama</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>No. Ring</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Warna Mutasi</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Jenis Burung</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Jenis Kelamin</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Induk</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>Peternak</td>
                                    <td>:</td>
                                    <td></td>
                                </tr>
                                </tbody>
                            </table>
                        
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline">Save changes</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/bdetails.blade.php ENDPATH**/ ?>