<?php $__env->startSection('content'); ?>    
<main role="main">
    <section class="content-header">
        <h1>
            Gallery
        </h1>
        <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><a href="birdfarm"><i class="fa fa-picture-o"></i> Gallery</a></li>
        </ol>
    </section>    

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header">
                        <div class="pull-left">
                            <h4>Bird Gallery</h4>    
                        </div>
                        <div class="pull-right">
                            <!-- Button -->
                            <div class="button">
                                <button type="button" class="btn btn-block btn-warning btn-sm" data-toggle="modal" data-target="#addTransaction">
                                    Add Image
                                </button>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="addTransaction">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title">Add Bird Image</h4>
                                        </div>
                                        
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <form method="POST" action="/gallery/addimage" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group">
                                                            <label for="file">Upload Foto</label>
                                                            <input type="file" name="file" class="form-control-file" id="file">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="role">Jenis Burung</label><br>
                                                            <select name="role" id="role" class="form-control">
                                                                <?php $__currentLoopData = $data['data']['user']['birdOwned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bird): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option selected value="<?php echo e($bird['id']); ?>"><?php echo e($bird['ring']); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                                            </select>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>
                                <!-- /.modal -->
                            </div>
                        </div>
                    </div>
                    <div class="box-body">

                        <div class="marketing text-center">        
                            
                            <div class="row text-center text-lg-left">
                                <?php $__currentLoopData = $data['data']['user']['birdOwned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $img['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 col-xs-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail" src="<?php echo e($image['src']); ?>" alt="">
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                                    
                            </div><!-- /.row -->
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>  
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/gallery/gallery.blade.php ENDPATH**/ ?>