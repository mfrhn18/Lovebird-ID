<head>
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(url('adminlte/bower_components/Ionicons/css/ionicons.min.css')); ?>">
  <!-- Morris charts -->
  <link rel="stylesheet" href="<?php echo e(url('adminlte/bower_components/morris.js/morris.css')); ?>">
</head>

<?php $__env->startSection('content'); ?>
<main role="main">
  <section class="content-header">
    <h1>
      Finance
      <small>Information</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li class="active"><a href="#"><i class="fa fa-dollar"></i> Finance</a></li>
    </ol>
    <br>
    <div class="pull-right">
      <?php echo $__env->make('finance.addtransaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </section>

  <section class="content">
    <br>
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Neraca Keuangan</h3>
        
        <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
      </div>

      <div class="box-body">
        <div class="row">
          <div class="col-md-12">
            <form>
              <select id="choice" name="filter">
                <option value="all">All</option>
                <?php $__currentLoopData = $data['dropdown']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e(substr($item, 0, 7)); ?>" <?php echo e(request()->get('filter', '') == substr($item, 0, 7) ? 'selected' : ''); ?>><?php echo e(substr($item, 8).' '.substr($item, 0, 4)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <button class="btn btn-primary btn-sm" type="submit">Submit</button>
            </form>

            <table id="table" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Deskripsi</th>
                  <th>Debet</th>
                  <th>Kredit</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Penjualan</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_101',0)); ?></td>
                  <td>Rp0</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_101',0)); ?></td>
                </tr>
                <tr>
                  <td>Lelang</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_102',0)); ?></td>
                  <td>Rp0</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_102',0)); ?></td>
                </tr>
                <tr>
                  <td>Pemasukan Lain-lain</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_103',0)); ?></td>
                  <td>Rp0</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_103',0)); ?></td>
                </tr>
                <tr>
                  <td>Tagihan</td>
                  <td>Rp0</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_201',0)); ?></td>
                  <td>Rp<?php echo e($data['aggregates']->get('_201',0)); ?></td>
                </tr>
                <tr>
                  <td>Operasional</td>
                  <td>Rp0</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_202',0)); ?></td>
                  <td>Rp<?php echo e($data['aggregates']->get('_202',0)); ?></td>
                </tr>
                <tr>
                  <td>Pengeluaran Lain-lain</td>
                  <td>Rp0</td>
                  <td>Rp<?php echo e($data['aggregates']->get('_203',0)); ?></td>
                  <td>Rp<?php echo e($data['aggregates']->get('_203',0)); ?></td>
                </tr>
                <tr>
                  <th>Total Keuangan</th>
                  <th>Rp<?php echo e($data['aggregates']->get('debet',0)); ?></th>
                  <th>Rp<?php echo e($data['aggregates']->get('kredit',0)); ?></th>
                  <th>Rp<?php echo e($data['aggregates']->get('debet',0) - $data['aggregates']->get('kredit',0)); ?></th>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
            
    <div class="box">
      <div class="box-body">
        <div class="row">
          <div class="col-md-12">
            <div class="input-group">
              <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Cari tanggal..">
            </div>
            <table id="myTable" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>Deskripsi</th>
                  <th>Jenis</th>
                  <th>Jumlah</th>
                </tr>
              </thead>
              <?php $__currentLoopData = $data['data']['data']['user']['journal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $trx['transaction']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                  <td><?php echo e($tx['timeStamp']); ?></td>
                  <td><?php echo e($tx['description']); ?></td>
                  <td><?php echo e($tx['type']); ?></td>
                  <td>Rp<?php echo e($tx['amount']); ?></td>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

  
</main>
<?php $__env->stopSection(); ?>


<script>
  var msg = '<?php echo e(Session::get('alert')); ?>';
  var exist = '<?php echo e(Session::has('alert')); ?>';
  if(exist){
    alert(msg);
  }

  function myFunction() {
  // Declare variables 
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      } 
    }
  }
</script>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/finance/finance.blade.php ENDPATH**/ ?>