<?php $__env->startSection('content'); ?>
<main role="main">

    <section class="content-header">
        <h1>
            Breeding
            <small>Details</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="breeding"><i class="glyphicon glyphicon-info-sign"></i> Breeding</a></li>
            <li class="active"><a href="#"> Details</a></li>
        </ol>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-body">
                        <div class="col-md-6">
                            <!-- Gallery -->
                            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                <!-- Wrapper for slides -->
                                <div class="text-center">
                                    <img class="d-block img-fluid" src="<?php echo e($data['data']['birdParentById']['image']['src']); ?>" width="450">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="row">
                                <div class="pull-left">
                                    <h3>Informasi Induk</h3>
                                </div>
                                <div class="pull-right">
                                    <?php echo $__env->make('bdaddbatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></br>
                                    <?php echo $__env->make('bdaddrec', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                            <div id="inforow" class="row">
                                <hr>
                                <table class="mt-3 pt-3 mb-1 pb-1" id="userdetails">
                                    <tbody>
                                        <tr>
                                            <th>Induk Jantan</th>
                                            <td>:</td>
                                            <td>
                                                <?php echo e($data['data']['birdParentById']['male']['ring']); ?>

                                                (<?php echo e($data['data']['birdParentById']['male']['species']); ?>)
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Induk Betina</th>
                                            <td>:</td>
                                            <td>
                                                <?php echo e($data['data']['birdParentById']['female']['ring']); ?>

                                                (<?php echo e($data['data']['birdParentById']['female']['species']); ?>)
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>No. Induk</th>
                                            <td>:</td>
                                            <td><?php echo e($data['data']['birdParentById']['noParent']); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Batch</th>
                                    <th>Status</th>
                                    <th>Egg</th>
                                    <th>Date</th>
                                    <th>Mortality</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <!-- Add data from database via GraphQL -->
                            <tbody>
                                <?php $__currentLoopData = $data['data']['birdParentById']['breedingRecord']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($brec['name']); ?></td>
                                    <td><?php echo e($brec['status']); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
        </div>
    </section>
  
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/breedingdetails.blade.php ENDPATH**/ ?>