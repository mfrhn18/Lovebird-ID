<?php $__env->startSection('content'); ?>    
<main role="main">
    <section class="content-header">
        <h1>
            Gallery
        </h1>
        <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active"><a href="birdfarm"><i class="fa fa-picture-o"></i> Gallery</a></li>
        </ol>
    </section>    

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header">
                        <div class="pull-left">
                            <h4>Bird Gallery</h4>    
                        </div>
                        <div class="pull-right">
                            <?php echo $__env->make('addimage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <div class="box-body">

                        <div class="container marketing text-center">        
                            
                            <div class="row text-center text-lg-left">
                                <?php $__currentLoopData = $data['data']['user']['birdOwned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $img['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-3 col-md-4 col-xs-6">
                                            <a href="#" class="d-block mb-4 h-100">
                                                <img class="img-fluid img-thumbnail" src="<?php echo e($image['src']); ?>" alt="">
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                                    
                            </div><!-- /.row -->
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>  
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/gallery.blade.php ENDPATH**/ ?>