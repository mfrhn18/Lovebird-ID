<?php $__env->startSection('content'); ?>
<main role="main">
    <section class="content-header">
        <h1>
            Journal
            <small>Details</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="finance"><i class="fa fa-dollar"></i> Finance</a></li>
            <li class="active"><a href="#"> Journal</a></li>
        </ol>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header">
                <div class="pull-left">
                    <hi class="box-title">
                        Jurnal <?php echo e($data['data']['data']['journalById']['timeStamp']); ?>

                    </h1>
                </div>
                <div class="pull-right">
                    <?php echo $__env->make('finance.addtransaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <table id="journal" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Deskripsi</th>
                                    <th>Jenis</th>
                                    <th>Jumlah</th>
                                    <th><?php echo $__env->make('finance.detailstrx', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $data['data']['data']['journalById']['transaction']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <td><?php echo e($tx['timeStamp']); ?></td>
                                <td><?php echo e($tx['description']); ?></td>
                                <td><?php echo e($tx['type']); ?></td>
                                <td>Rp<?php echo e($tx['amount']); ?></td>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/finance/journaldetails.blade.php ENDPATH**/ ?>