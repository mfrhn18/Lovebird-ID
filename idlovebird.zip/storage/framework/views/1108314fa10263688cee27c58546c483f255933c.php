<!-- Button -->
<div class="button">
    <button type="button" class="btn btn-block btn-warning btn-sm" data-toggle="modal" data-target="#addTransaction">
        Add Image
    </button>
</div>

<!-- Modal -->
<div class="modal fade" id="addTransaction">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">Add Bird Image</h4>
            </div>
            
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <form method="POST" action="<?php echo e(route('addimage.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="file">Upload Foto</label>
                                <input type="file" name="file" class="form-control-file" id="file">
                            </div>
                            <div class="form-group">
                                <label for="role">Jenis Burung</label><br>
                                <select name="role" id="role" class="form-control">
                                    <?php $__currentLoopData = $data['data']['user']['birdOwned']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bird): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option selected value="<?php echo e($bird['id']); ?>"><?php echo e($bird['ring']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->
</div>

    <script>
        var today = new Date();
        var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
        var timeStamp = today.getHours() + ":" + today.getMinutes()+", "+today.getDate()+'/'+(today.getMonth()+1)+'/'+today.getFullYear();
        document.getElementById("date").innerHTML = date;
        document.getElementById("time").innerHTML = timeStamp;
    </script><?php /**PATH C:\xampp\htdocs\idlovebird\resources\views/gallery/addimage.blade.php ENDPATH**/ ?>