<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dropfile extends Model
{
    protected $guarded = [];
}
