<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Client;

class FinanceController extends Controller
{
    public function index()
    {
        setlocale(LC_ALL, 'id_ID');

        $token = Session::get('token');

        $client = new Client;      
        $request = $client->post(ENV('API_URLL'), [
            'headers'=>[
                'Authorization' => 'Bearer ' . $token
            ],
            'json' => [
                'query' => 'query{user{journal{id timeStamp transaction{id amount timeStamp type description isFinish}}
                }}'
                ]
            ]
        );
        $response = $request->getBody()->getContents();
        $dataTrx = json_decode($response, true);
        
        $jurnal = collect($dataTrx['data']['user']['journal'])->flatten(2)->reject(function ($value, $key) {
            return !is_array($value);
        });

        $dropdown = $jurnal->map(function($item){
            return substr($item['timeStamp'], 0, 7);
        })->unique()
            ->sort(function($a, $b)  { 
                if ($a == $b) return 0;
                return ($a > $b) ? -1 : 1; 
            })
            ->values()
            ->transform(function($item){
                return $item.'_'.strftime('%B', strtotime($item.'-01'));
            });
        // dump($dropdown);

        $aggregates = collect();

        $transactions = $jurnal->groupBy(function ($item) {
            return '_'.substr($item['type'], 0, 3);
        });
        
        $filter = isset($_GET['filter']) ? strtolower($_GET['filter']) : 'all';
        // dump($filter);
        if($filter == 'all'){
            $transactions = $jurnal->groupBy(function ($item) {
                return '_'.substr($item['type'], 0, 3);
            });
        }else{
            $transactions = $jurnal->filter(function($item, $key) use($filter){
                return substr($item['timeStamp'], 0, 7) == $filter;
            })->groupBy(function ($item) {
                return '_'.substr($item['type'], 0, 3);
            });
        }

        $aggregates = $transactions->map(function($trx_type){
            return $trx_type->sum('amount');
        });

        //total
        $aggregates->put('total', $aggregates->sum()); 

        //debet
        $aggregates->put('debet', $aggregates->filter(function($item, $key){
            return strpos($key, '_10') === 0;
        })->sum()); 

        //kredit
        $aggregates->put('kredit', $aggregates->filter(function($item, $key){
            return strpos($key, '_20') === 0;
        })->sum()); 

        // dump($aggregates);
        // exit;

        // $transactions = $jurnal->groupBy([function ($item) {
        //     return substr($item['timeStamp'], 0, 4);
        // }, function ($item) {
        //     return '_'.substr($item['timeStamp'], 5, 2);
        // }, function ($item) {
        //     return substr($item['type'], 0, 3);
        // }]);

        // dump($transactions);

        // $aggregates = $transactions->map(function($trx_year){
        //     return $trx_year->map(function($trx_month){
        //         return $trx_month->map(function($trx_type){
        //             return $trx_type->sum('amount');
        //         });
        //     });
        // })->sortKeysDesc()
        //     ->transform(function ($item) {
        //         return $item->sortKeys();
        //     });

        // $collectTypePenjualan = collect(); $collectTypeLelang = collect(); $collectTypePemasukan = collect();
        // $collectTypeTagihan = collect(); $collectTypeOperasional = collect(); $collectTypePengeluaran = collect();
        // //SORT
        // $collectTypePenjualanOct = collect(); $collectTypeLelangOct = collect(); $collectTypePemasukanOct = collect();
        // $collectTypeTagihanOct = collect(); $collectTypeOprOct = collect(); $collectTypePengeluaranOct = collect();
        // //
        // $collectTypePenjualanNov = collect(); $collectTypeLelangNov = collect(); $collectTypePemasukanNov = collect();
        // $collectTypeTagihanNov = collect(); $collectTypeOprNov = collect(); $collectTypePengeluaranNov = collect();
        // //
        // $pemasukan1 = 0;
        // $pemasukan2 = 0;
        // $pemasukan3 = 0;
        // $pengeluaran1 = 0;
        // $pengeluaran2 = 0;
        // $pengeluaran3 = 0;
        // //
        // $pemasukanOct1 = 0; $pemasukanOct2 = 0; $pemasukanOct3 = 0;
        // $pengeluaranOct1 = 0; $pengeluaranOct2 = 0; $pengeluaranOct3 = 0;
        // //
        // $pemasukanNov1 = 0; $pemasukanNov2 = 0; $pemasukanNov3 = 0;
        // $pengeluaranNov1 = 0; $pengeluaranNov2 = 0; $pengeluaranNov3 = 0;

        // foreach($dataTrx['data']['user']['journal'] as $jr){
        //     foreach($jr['transaction'] as $trx){
        //         $type = explode("-", $trx['type']);
        //         if($type[0] == "101"){
        //             $pemasukan1 += $trx['amount'];
        //             $collectTypePenjualan->push([
        //                 "type" => $type[0],
        //                 "description" => $trx['description'],
        //                 "amount" => $trx['amount']
        //             ]);
        //         }
        //         else if($type[0] == "102"){
        //             $pemasukan2 += $trx['amount'];
        //             $collectTypeLelang->push([
        //                 "type" => $type[0],
        //                 "description" => $trx['description'],
        //                 "amount" => $trx['amount']
        //             ]);
        //         }
        //         else if($type[0] == "103"){
        //             $pemasukan3 += $trx['amount'];
        //             $collectTypePemasukan->push([
        //                 "type" => $type[0],
        //                 "description" => $trx['description'],
        //                 "amount" => $trx['amount']
        //             ]);
        //         }
        //         else if($type[0] == "201"){
        //             $pengeluaran1 += $trx['amount'];
        //             $collectTypeTagihan->push([
        //                 "type" => $type[0],
        //                 "description" => $trx['description'],
        //                 "amount" => $trx['amount']
        //             ]);
        //         }
        //         else if($type[0] == "202"){
        //             $pengeluaran2 += $trx['amount'];
        //             $collectTypeOperasional->push([
        //                 "type" => $type[0],
        //                 "description" => $trx['description'],
        //                 "amount" => $trx['amount']
        //             ]);
        //         }
        //         else{
        //             $pengeluaran3 += $trx['amount'];
        //             $collectTypePengeluaran->push([
        //                 "type" => $type[0],
        //                 "description" => $trx['description'],
        //                 "amount" => $trx['amount']
        //             ]);
        //         }
        //     }

        //     foreach($jr['transaction'] as $trx){
        //         $dates = explode("-",$trx['timeStamp']);
        //         if($dates[0] == "2019" && $dates[1] == "10"){
        //             $type = explode("-", $trx['type']);
        //             if($type[0] == "101"){
        //                 $pemasukanOct1 += $trx['amount'];
        //                 $collectTypePenjualanOct->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "102"){
        //                 $pemasukanOct2 += $trx['amount'];
        //                 $collectTypeLelangOct->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "103"){
        //                 $pemasukanOct3 += $trx['amount'];
        //                 $collectTypePemasukanOct->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "201"){
        //                 $pengeluaranOct1 += $trx['amount'];
        //                 $collectTypeTagihanOct->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "202"){
        //                 $pengeluaranOct2 += $trx['amount'];
        //                 $collectTypeOprOct->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else{
        //                 $pengeluaranOct3 += $trx['amount'];
        //                 $collectTypePengeluaranOct->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //         }

        //         if($dates[0] == "2019" && $dates[1] == "11"){
        //             $type = explode("-", $trx['type']);
        //             if($type[0] == "101"){
        //                 $pemasukanNov1 += $trx['amount'];
        //                 $collectTypePenjualanNov->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "102"){
        //                 $pemasukanNov2 += $trx['amount'];
        //                 $collectTypeLelangNov->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "103"){
        //                 $pemasukanNov3 += $trx['amount'];
        //                 $collectTypePemasukanNov->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "201"){
        //                 $pengeluaranNov1 += $trx['amount'];
        //                 $collectTypeTagihanNov->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else if($type[0] == "202"){
        //                 $pengeluaranNov2 += $trx['amount'];
        //                 $collectTypeOprNov->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //             else{
        //                 $pengeluaranNov3 += $trx['amount'];
        //                 $collectTypePengeluaranNov->push([
        //                     "type" => $type[0],
        //                     "description" => $trx['description'],
        //                     "amount" => $trx['amount']
        //                 ]);
        //             }
        //         }
        //     }
        // }

        $data = [
            // "jualOct" => $pemasukanOct1, "lelOct" => $pemasukanOct2, "mskOct" => $pemasukanOct3,
            // "tJualOct" => $collectTypePenjualanOct, "tLelOct" => $collectTypeLelangOct, "tMskOct" => $collectTypePemasukanOct,
            // "tagOct" => $pengeluaranOct1, "oprOct" => $pengeluaranOct2, "kelOct" => $pengeluaranOct3,
            // "tTagOct" => $collectTypeTagihanOct, "tOprOct" => $collectTypeOprOct, "tKelOct" => $collectTypePengeluaranOct,
            // "debOct" => ($pemasukanOct1+$pemasukanOct2+$pemasukanOct3), "kreOct" => ($pengeluaranOct1+$pengeluaranOct2+$pengeluaranOct3),
            // "jualNov" => $pemasukanNov1, "lelNov" => $pemasukanNov2, "mskNov" => $pemasukanNov3,
            // "tJualNov" => $collectTypePenjualanNov, "tLelNov" => $collectTypeLelangNov, "tMskNov" => $collectTypePemasukanNov,
            // "tagNov" => $pengeluaranNov1, "oprNov" => $pengeluaranNov2, "kelNov" => $pengeluaranNov3,
            // "tTagNov" => $collectTypeTagihanNov, "tOprNov" => $collectTypeOprNov, "tKelNov" => $collectTypePengeluaranNov,
            // "debNov" => ($pemasukanNov1+$pemasukanNov2+$pemasukanNov3), "kreNov" => ($pengeluaranNov1+$pengeluaranNov2+$pengeluaranNov3),
            // "penjualan" => $pemasukan1,
            // "lelang" => $pemasukan2,
            // "pemasukanlain" => $pemasukan3,
            // "tagihan" => $pengeluaran1,
            // "operasional" => $pengeluaran2,
            // "pengeluaranlain" => $pengeluaran3,
            // "totaljual" => $collectTypePenjualan,
            // "totallelang" => $collectTypeLelang,
            // "totalmasuk" => $collectTypePemasukan,
            // "totaltagih" => $collectTypeTagihan,
            // "totalopr" => $collectTypeOperasional,
            // "totalkeluar" => $collectTypePengeluaran,
            // "masuk" => ($pemasukan1+$pemasukan2+$pemasukan3),
            // "keluar" => ($pengeluaran1+$pengeluaran2+$pengeluaran3),
            "data" => $dataTrx,
            "dropdown" => $dropdown,
            "aggregates" => $aggregates,
        ];
        //dd($data);
        return view('finance.finance')->withData($data);
    }

    public function createtrx(Request $request)
    {
        $token = Session::get('token');
        $date=now();
        $jts=$date->format('d-m-Y');

        $datepicker=$request->datepicker;
        $type=$request->type;
        $desc=$request->desc;
        $amount=$request->amount;

        // dd($datepicker,$type,$desc,$amount,$date,$jts);

        $client = new Client;
        $request = $client->post(ENV('API_URLL'), [
            'headers'=>[
                'Authorization' => 'Bearer ' . $token
            ],
            'json' => [
                'query' => 'mutation{
                    createJournal(
                        timeStamp:"'.$jts.'"
                    ){
                        id
                    }
                }'
                ]
            ]
        );
        $response = $request->getBody()->getContents();
        $data = json_decode($response, true);
        $jid = $data['data']['createJournal']['id'];
        
        if($jid){
            Session::put('id',$jid);
            $request = $client->post(ENV('API_URLL'), [
                'headers'=>[
                    'Authorization' => 'Bearer ' . $token
                ],
                'json' => [
                    'query' => 'mutation{
                        createTransaction(
                            type:"'.$type.'",
                            description:"'.$desc.'",
                            amount:"'.$amount.'",
                            timeStamp:"'.$datepicker.'",
                            isFinish:true
                        ){
                            id
                        }
                    }'
                    ]
                ]
            );
            $response = $request->getBody()->getContents();
            $data = json_decode($response, true);
            $tid = $data['data']['createTransaction']['id'];

            if($tid){
                Session::put('id', $tid);
                Session::put('jid', $jid);
                $request = $client->post(ENV('API_URLL'), [
                    'headers'=>[
                        'Authorization' => 'Bearer ' . $token
                    ],
                    'json' => [
                        'query' => 'mutation{
                            updateJournalTransactionRelation(journalId:"'.$jid.'", transactionId:"'.$tid.'"){
                                id
                            }
                        }'
                        ]
                    ]
                );
                $response = $request->getBody()->getContents();
                $data = json_decode($response, true);
                return redirect('finance');
            }
            else{
                return redirect('finance')->with('alert!', 'Data tidak tersimpan!');
            }
        }
        else{
            return redirect('finance')->with('alert!', 'Data tidak tersimpan!');
        }
    }

}
