<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use GuzzleHttp\Client;

class BirdDetailsController extends Controller
{
    public function index()
    {
        return view('birdfarm.birddetails');
    }

    public function show($id)
    {
        $token = Session::get('token');
        
        $client = new Client;
        $request = $client->post(ENV('API_URLL'), [
            'headers'=>[
                'Authorization' => 'Bearer ' . $token
            ],
            'json' => [
                'query' => 'query{birdFilterById(filter:"'.$id.'"){
                    id name ring type species gender age breeder image{src} parent{noParent}
                }}'
                ]
            ]
        );

        $response = $request->getBody()->getContents();
        $data = json_decode($response, true);

        return view('birdfarm.birddetails')->withData($data);
    }

    public function edit($id)
    {
        $token = Session::get('token');
        
        $client = new Client;
        $request = $client->post(ENV('API_URLL'), [
            'headers'=>[
                'Authorization' => 'Bearer ' . $token
            ],
            'json' => [
                'query' => 'query{birdFilterById(filter:"'.$id.'"){
                    id name ring type species gender age breeder image{src} parent{id noParent}
                }}'
                ]
            ]
        );

        $response = $request->getBody()->getContents();
        $datax = json_decode($response, true);
        $parent = $datax['data']['birdFilterById']['parent'];
        if($parent['noParent'] == null){
            $request = $client->post(ENV('API_URLL'), [
                'headers'=>[
                    'Authorization' => 'Bearer ' . $token
                ],
                'json' => [
                    'query' => 'query{user{
                        birdParent{id noParent}
                    }}'
                    ]
                ]
            );
            $response = $request->getBody()->getContents();
            $noParent = json_decode($response, true);
        }
        
        $data = [
            "data" => $datax,
            "parent" => $noParent
        ];

        return view('birdfarm.editbird')->withData($data);
    }

    public function store(Request $request, $id)
    {
        $token = Session::get('token');
        $img    = $request->file;
        $species= $request->species;
        $type   = $request->type;
        $name   = $request->name;
        $age    = $request->age;
        $parent = $request->parent;
        $breeder= $request->breeder;

        $client = new Client;
        $request = $client->post(ENV('API_URLL'), [
            'headers'=>[
                'Authorization' => 'Bearer ' . $token
            ],
            'json' => [
                'query' => 'mutation
                {
                    updateBirdInformation{
                        name:"'.$name.'",
                        type:"'.$type.'",
                        birdId:"'.$id.'",
                        parentId:"'.$parent.'",
                        species:"'.$species.'",
                        age:"'.$age.'",
                        breeder:"'.$breeder.'"
                    }
                }'
                ]
            ]
        );

        $response = $request->getBody()->getContents();
        $data = json_decode($response, true);

        return view('birddetails')->withData($data);
    }
}